#!/usr/bin/env bash

sudo apt-get install -y usbmount
sudo sed -i s/MountFlags=slave/MountFlags=shared/ /lib/systemd/system/systemd-udevd.service
if [ ! -d /home/pi/services ]; then
    sudo mkdir /home/pi/services
fi
sudo cp /home/pi/piSignagePro/misc/copy-service.sh /home/pi/services
sudo chmod a+x /home/pi/services/copy-service.sh
sudo cp /home/pi/piSignagePro/misc/autoload.service /lib/systemd/system/autoload.service
sudo systemctl enable autoload.service
sleep 5
sudo reboot now
