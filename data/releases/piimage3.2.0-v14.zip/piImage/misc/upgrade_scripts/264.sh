#!/usr/bin/env bash


if grep -q "buster" /etc/*-release; then
    echo "Buster release"

    # upgrade rpi firmware
    echo "Updating rpi firmware https://github.com/popcornmix/omxplayer/issues/749"
    sudo SKIP_WARNING=1 rpi-update  77444b020fe5b70f76d1921ae9c4cefd045d74bc
fi

