#!/bin/bash

if grep -q "enable_tvout" /boot/config.txt
then
    echo "enable_tvout is present"
else
    echo "adding enable_tvout as comment line"
    echo "#enable_tvout=1" | sudo tee -a /boot/config.txt > /dev/null
fi



