#!/usr/bin/env bash

# needed for omxplayer srt
sudo apt-get install -y ttf-freefont