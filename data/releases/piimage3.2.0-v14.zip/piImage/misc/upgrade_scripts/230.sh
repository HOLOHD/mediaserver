#!/usr/bin/env bash

# make openvg
echo "OpenVG update"

cd /home/pi/piSignagePro/tools/openvg_display
chmod +x make.sh
./make.sh

echo "Youtube DL"
sudo pip install --upgrade youtube-dl

echo "Xdotool"
sudo apt-get -y install xdotool

sudo cp /home/pi/piSignagePro/misc/pisignage-import.service /etc/systemd/system/
sudo systemctl enable pisignage-import.service

sudo cp /home/pi/piSignagePro/misc/40-pisignage-import.rules /etc/udev/rules.d/
sudo udevadm control --reload

chmod +x /home/pi/piSignagePro/misc/import-assets.sh

cd /home/pi/
echo "MPV"
#https://unix.stackexchange.com/questions/159094/how-to-install-a-deb-file-by-dpkg-i-or-by-apt
if [ $(getconf _NPROCESSORS_ONLN) -eq 4 ]; then
    wget https://s3.amazonaws.com/pisignage/assets/binaries/mpv_0.27.2_armhf.deb
    #wget https://s3.amazonaws.com/pisignage/assets/binaries/mpv_0.29.1_armhf.deb
    sudo apt-get update
    sudo apt install -y ./mpv_*.deb
    sudo apt-get update
    sudo apt install -f
    sudo apt install -y ./mpv_*.deb           #try again if failed before
fi

