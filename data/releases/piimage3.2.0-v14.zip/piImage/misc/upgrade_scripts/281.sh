#!/usr/bin/env bash


if grep -q "buster" /etc/*-release; then
    echo "Buster release"

    #for 2 display support
    sudo apt-get purge -y gldriver-test wmctrl
fi

