#!/bin/sh
TEST_EXT_IP="208.67.232.222" # IP used for testing if an external connection can be made
TEST_HOST="pisignage.com" # Test hostname used to check if DNS is working

PATH="/sbin:/usr/sbin:/bin:/usr/bin"
export PATH
netstatus="OK"
dnstest="OK"
pingtest="OK"
linkstatus="DOWN"
dhcpserver="NO"

linkstatus=$(sudo ethtool eth0 | grep "Link detected" |  cut -d':' --complement -s -f1)
if [ $linkstatus == "yes" ]; then
   linkstatus="UP"
else
   linkstatus="DOWN"
   netstatus="FAIL"
fi

PING=$(ping -c1 -n $TEST_EXT_IP)
if [ "$?" -ne "0" ]; then
	netstatus="FAIL"
	pingtest="FAIL"
fi

dhcpserver=$(sudo nmap --script broadcast-dhcp-discover |grep "Server Identifier" |  cut -d':' --complement -s -f1)

RES=$(host $TEST_HOST)
dns=`echo $RES | awk '{print match($0,"pisignage")}'`;
if [ $dns -ne 0 ]; then
    dnstest="OK"
else
    dnstest="FAIL"
    netstatus="FAIL"
fi

echo  "{\"LINK\":\""$linkstatus"\",\"DHCP\":\""$dhcpserver"\",\"PING\":\""$pingtest"\",\"DNS\":\""$dnstest"\",\"NETSTATUS\":\""$netstatus"\" }"
