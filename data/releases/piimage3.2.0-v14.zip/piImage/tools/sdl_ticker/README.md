http://lazyfoo.net/tutorials/SDL/01_hello_SDL/index2.php
https://cairographics.org/SDL/
https://dthompson.us/font-rendering-in-opengl-with-pango-and-cairo.html