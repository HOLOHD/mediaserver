echo "Adding chromium data directory"
mkdir -p $HOME/apps-data/.cache/chromium
mkdir -p $HOME/apps-data/.config/chromium
chmod -R 777 $HOME/apps-data