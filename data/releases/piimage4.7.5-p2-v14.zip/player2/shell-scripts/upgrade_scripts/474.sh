echo "Get a list of WiFi devices in player-UI using iwlist cmd"
sudo apt-get -y install wireless-tools