echo  "Adding evince, xdotool and wmctrl for PDF play"
sudo apt-get -y install evince xdotool wmctrl