self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5c1cffb9aece6562d6914bcfdc3e6638",
    "url": "/newui/index.html"
  },
  {
    "revision": "d8684427bf51a05c3f96",
    "url": "/newui/static/css/main.5e2cca15.chunk.css"
  },
  {
    "revision": "bdc56fbcd0f928523bcd",
    "url": "/newui/static/js/2.21bccf5d.chunk.js"
  },
  {
    "revision": "77e7f328dacc981fca681ee4ae94d669",
    "url": "/newui/static/js/2.21bccf5d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d8684427bf51a05c3f96",
    "url": "/newui/static/js/main.2c736611.chunk.js"
  },
  {
    "revision": "59dcc94cd398377e9c5c",
    "url": "/newui/static/js/runtime-main.7dbccc6b.js"
  },
  {
    "revision": "60371d9d82df4db7ceaf3164e380f92a",
    "url": "/newui/static/media/logo.60371d9d.svg"
  }
]);