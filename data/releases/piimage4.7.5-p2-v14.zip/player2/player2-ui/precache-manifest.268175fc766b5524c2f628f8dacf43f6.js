self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9d4037bb9f32c598761f3c3f7192d3f2",
    "url": "/newui/index.html"
  },
  {
    "revision": "06d38c6c98d72adda614",
    "url": "/newui/static/css/main.5e2cca15.chunk.css"
  },
  {
    "revision": "bdc56fbcd0f928523bcd",
    "url": "/newui/static/js/2.21bccf5d.chunk.js"
  },
  {
    "revision": "77e7f328dacc981fca681ee4ae94d669",
    "url": "/newui/static/js/2.21bccf5d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "06d38c6c98d72adda614",
    "url": "/newui/static/js/main.eb383068.chunk.js"
  },
  {
    "revision": "59dcc94cd398377e9c5c",
    "url": "/newui/static/js/runtime-main.7dbccc6b.js"
  },
  {
    "revision": "60371d9d82df4db7ceaf3164e380f92a",
    "url": "/newui/static/media/logo.60371d9d.svg"
  }
]);