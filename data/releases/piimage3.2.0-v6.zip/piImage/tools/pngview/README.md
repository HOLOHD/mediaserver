# pngview

Utility to display a PNG image on the Raspberry Pi screen using the Dispmanx windowing system. 

    Usage: pngview  [-l <layer>] [-x <offset>] [-y <offset>] <file.png>

    -l - DispmanX layer number
    -x - offset (pixels from the left)
    -y - offset (pixels from the top)

