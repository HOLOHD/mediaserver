#!/usr/bin/env bash
cd /home/pi/piSignagePro/tools/openvg_display
make
sudo rm -f /usr/local/bin/openvg_display
sudo cp /home/pi/piSignagePro/tools/openvg_display/openvg_display /usr/local/bin/openvg_display
sudo chmod +x /usr/local/bin/openvg_display
