#!/bin/sh
CONFIG="/boot/config.txt"
HEIGHT=""
WIDTH=""

Portrait90(){
	echo "****  it's portrait 90 Degree  ****"
	sudo sed -i "s/.*display_rotate.*/display_rotate=1/" $CONFIG
	sudo sed -i   -e "s/.*framebuffer_width.*/framebuffer_width=$HEIGHT/" -e "s/.*framebuffer_height.*/framebuffer_height=$WIDTH/"  $CONFIG
}

Portrait270(){
	echo "****  it's portrait 270 Degree ****"
	sudo sed -i "s/.*display_rotate.*/display_rotate=3/" $CONFIG
	sudo sed -i   -e "s/.*framebuffer_width.*/framebuffer_width=$HEIGHT/" -e "s/.*framebuffer_height.*/framebuffer_height=$WIDTH/"  $CONFIG
}

LandScape(){
	echo "****  its landscape  ****"
	sudo sed -i 's/.*display_rotate.*/display_rotate=0/' $CONFIG
	sudo sed -i -e "s/.*framebuffer_width.*/framebuffer_width=$WIDTH/" -e "s/.*framebuffer_height.*/framebuffer_height=$HEIGHT/"  $CONFIG
}

Large1080(){
	HEIGHT="1080"
	WIDTH="1920"
	echo "**** 1080p screen  ****"
	sudo sed -i 's/.*hdmi_mode.*/hdmi_mode=16/' $CONFIG
	sudo sed -i 's/.*framebuffer_height.*/framebuffer_height=1080/'  $CONFIG
	sudo sed -i 's/.*framebuffer_width.*/framebuffer_width=1920/' $CONFIG

	sudo sed -i 's/.*hdmi_force_hotplug=1.*/hdmi_force_hotplug=1/' $CONFIG
	sudo sed -i 's/.*hdmi_drive.*/hdmi_drive=2/' $CONFIG
}

Small720(){
	HEIGHT="720"
	WIDTH="1280"
	echo "**** 720p screen  ****"
	sudo sed -i 's/.*hdmi_mode.*/hdmi_mode=4/' $CONFIG
	sudo sed -i 's/.*framebuffer_height.*/framebuffer_height=720/'  $CONFIG
    sudo sed -i 's/.*framebuffer_width.*/framebuffer_width=1280/' $CONFIG

    sudo sed -i 's/.*hdmi_force_hotplug=1.*/hdmi_force_hotplug=1/' $CONFIG
	sudo sed -i 's/.*hdmi_drive.*/hdmi_drive=2/' $CONFIG
}

PALsdtv(){
	HEIGHT="576"
	WIDTH="720"
	echo "**** PAL screen  ****"
	sudo sed -i 's/.*hdmi_force_hotplug=1.*/#hdmi_force_hotplug=1/' $CONFIG
	sudo sed -i 's/.*hdmi_drive.*/#hdmi_drive=2/' $CONFIG
	
	sudo sed -i 's/.*sdtv_mode.*/sdtv_mode=2/' $CONFIG
}

NTSCsdtv(){
	HEIGHT="480"
	WIDTH="720"
	echo "**** NTSC screen  ****"
	sudo sed -i 's/.*hdmi_force_hotplug=1.*/#hdmi_force_hotplug=1/' $CONFIG
	sudo sed -i 's/.*hdmi_drive.*/#hdmi_drive=2/' $CONFIG
	
	sudo sed -i 's/.*sdtv_mode.*/sdtv_mode=0/' $CONFIG
}

case $2 in 
	"720p") Small720
	;;
	"1080p") Large1080
	;;
	"PAL") PALsdtv
	;;
	"NTSC") NTSCsdtv
	;;
esac

case $1 in
    "portrait") Portrait90
    ;;
    "portrait270") Portrait270
	;;
    "landscape") LandScape
    ;;
esac

