#!/bin/sh
##########################################################################################
###  Run this script as a super user to chnage hostname
##########################################################################################

DHCLIENT="/etc/dhcp/dhclient.conf"
HOSTS="/etc/hosts"
HOSTNAME="/etc/hostname"
newname=$1

echo "changing name "
sed -i "s/.*send host-name \".*/send host-name \"$newname\";/" $DHCLIENT
sed -i "s/^send host-name =.*/#send host-name = gethostname();/" $DHCLIENT
sed -i "s/.*127.0.1.1.*/127.0.1.1	$newname/" $HOSTS
echo "$newname" > $HOSTNAME