#!/bin/bash

unclutter -idle 5 &
cd /home/pi/piSignagePro

sudo bash /home/pi/piSignagePro/misc/player-setup.sh

. /home/pi/.bash_profile
export WEBKIT_DISABLE_TBS=1
node pi-monitor.js
sleep 10 
sudo kill $(pidof python omx.py)
sudo pkill omxplayer
sleep infinity