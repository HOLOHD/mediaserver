#!/usr/bin/env bash


if grep -q "buster" /etc/*-release; then
    echo "Buster release"

    # make new pngview
    echo "image view"
    cd /home/pi/piSignagePro/tools/pngview2
    chmod +x make.sh
    ./make.sh

    # make  sdl ticker
    echo "SDL ticker"
    cd /home/pi/piSignagePro/tools/sdl_ticker
    chmod +x make.sh
    ./make.sh

fi

