#!/usr/bin/env bash

# install livestream if not installed
sudo apt-get -y install python-pip
sudo pip install livestreamer

# make changes to youtube plugin
sudo sed -i 's/.*http.get(API_VIDEO_INFO, params=params.*/\tres = http.get(API_VIDEO_INFO, params=params , headers=HLS_HEADERS)/' /usr/local/lib/python2.7/dist-packages/livestreamer/plugins/youtube.py
