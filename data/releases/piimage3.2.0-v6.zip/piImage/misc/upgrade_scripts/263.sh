#!/usr/bin/env bash


if grep -q "buster" /etc/*-release; then
    echo "Buster release"

    # make  sdl ticker
    echo "SDL ticker"
    cd /home/pi/piSignagePro/tools/sdl_ticker
    chmod +x make.sh
    ./make.sh

fi

