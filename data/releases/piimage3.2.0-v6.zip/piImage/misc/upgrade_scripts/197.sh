#!/usr/bin/env bash

# make opnvg
cd /home/pi/piSignagePro/tools/openvg_display
chmod +x make.sh
./make.sh

sudo sed -i 's/player_embedded/detailpage/' /usr/local/lib/python2.7/dist-packages/livestreamer/plugins/youtube.py

sudo -H pip install --upgrade youtube-dl