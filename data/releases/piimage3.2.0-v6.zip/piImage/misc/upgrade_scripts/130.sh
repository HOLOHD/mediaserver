#!/usr/bin/env bash
# Made change to omx.py , welcome screen is customized to 'display orientaion'
# remove old omx.py and paste new script
rm -rf /home/pi/omx.py
cp /home/pi/piSignagePro/misc/omx.py /home/pi/
sudo chmod 755 /home/pi/omx.py