#!/bin/sh
######################################################################
# This script will take do a manual upgrade after the image copy to pi
#You can upgrade players manually using the following steps (we have tested this in our Pi)

#Prerequisites
#1. You need internet connection so that upgrade can do “npm install” for the new modules.

#Steps
#1. Copy the image file to /home/pi directory either through scp or using wget.
#   The file is available at http://pisignage.com/releases/piimage1.5.3.zip
#2. Copy the attached upgrade shell script file to /home/pi folder
#3. run the script as “./upgrade-manual.sh piimage1.5.3.zip” from /home/pi folder


#Fallback
#————
#1. The old firmware will be available at /home/pi/piSignage.prev folder in case of any issues you face
#   with the new release. You can just rename the folder to /home/pi/piSignagePro after deleting the piSignagePro folder
#####################################################################

cd /home/pi

if [ -z $1 ]; then
    echo "Please copy the image zip file to /home/pi folder and provide the image file name"
    exit 1
fi
if [ ! -f "$1" ]
then
    echo "The image file does not exist"
    exit 1
fi


echo "check .problem directory"
if [ -d "/home/pi/piSignagePro.problem" ]; then
	echo "directory exist"
	sudo rm -rf  /home/pi/piSignagePro.problem
else
	echo "directory does not exist"
fi

echo "installing new version of software from $1"

# kill forever process
sudo pkill -f forever
sudo pkill -f node
sudo pkill -f uzbl
sudo pkill -f omx
sudo fbi -T 1 ~/piupdate.png &

echo "saving the current image"
sudo rm -rf  ~/piSignagePro.prev
mv ~/piSignagePro ~/piSignagePro.prev

echo "unzipping the New pi image"
unzip $1
mv ~/piImage ~/piSignagePro

echo "copying configuration files"
cp ~/piSignagePro.prev/config/_config.json ~/piSignagePro/config
cp ~/piSignagePro.prev/config/_settings.json ~/piSignagePro/config

echo "copying the previous node modules"
cp -R ~/piSignagePro.prev/node_modules ~/piSignagePro

cd ~/piSignagePro

chmod +x misc/upgrade.sh
chmod +x misc/upgrade-manual.sh
chmod +x misc/downgrade.sh
chmod +x misc/network-config
chmod -R +x misc/upgrade_scripts

echo "installing npm packages"
npm install
echo "adding line in socket.io npm"
sed "s/.*self\.transport\.onClose.*/if \(self\.transport\) self\.transport\.onClose\(\)/" -i ~/piSignagePro/node_modules/socket.io-client/lib/socket.js

file="pi-upgrade.js"
if [ -f "$file" ]
then
	node $file
fi

sync

rm ~/piSignagePro/misc/install.sh ~/piSignagePro/misc/autostart

sudo reboot
