#!/usr/bin/env bash


if grep -q "buster" /etc/*-release; then
    echo "Buster release"

    sudo apt-get -y update && sudo apt-get -y upgrade
    sudo apt-get update --fix-missing

    # for node-canvas installation
    sudo apt install -y libgif-dev

    # make new pngview
    echo "image view"
    cd /home/pi/piSignagePro/tools/pngview2
    chmod +x make.sh
    ./make.sh

    # make  sdl ticker
    echo "SDL ticker"
    cd /home/pi/piSignagePro/tools/sdl_ticker
    chmod +x make.sh
    ./make.sh

    # make npm install after upgrade again for text2png
    echo "npm install text2png"
    cd /home/pi/piSignagePro
    rm -rf node_modules/text2png
    npm install text2png
fi

sudo pip install --upgrade youtube-dl
