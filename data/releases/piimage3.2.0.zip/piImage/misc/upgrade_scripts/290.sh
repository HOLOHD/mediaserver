#!/usr/bin/env bash

sudo -H pip install --upgrade youtube-dl
sudo apt-get update

if grep -q "buster" /etc/*-release; then
  echo "Buster release"
  #sudo apt full-upgrade -y
  echo "It is advised you do 'sudo apt full-upgrade -y &' to fix few firmware issues "
  echo "****** You could upgrade to node v14.0 by executing /home/pi/piSignagePro/misc/upgrade_scripts/upgrade_to_version14.sh *****"
fi
