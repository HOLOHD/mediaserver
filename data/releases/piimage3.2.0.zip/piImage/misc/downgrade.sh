#!/bin/sh
####################################################################
# this script will take care of restoring the old image in case of issue with new one
#move the previous image
#reboot
#####################################################################

# kill forever process
pkill -f forever
pkill -f node
pkill -f uzbl
pkill -f omx

cd ~

echo "rolling back to previous release"

if [ -d "/home/pi/piSignagePro.prev" ]
then
    rm -rf  ~/piSignagePro.problem
    mv  ~/piSignagePro  ~/piSignagePro.problem
    cp -a  ~/piSignagePro.prev/  ~/piSignagePro
    sync
    sudo reboot
fi

