#!/usr/bin/env bash
cd /home/pi/piSignagePro/tools/pngview
make
sudo rm -f /usr/local/bin/pngview
sudo cp /home/pi/piSignagePro/tools/pngview/pngview /usr/local/bin/pngview
sudo chmod +x /usr/local/bin/pngview
